package com.coffeeline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoffeelineAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
