package com.coffeeline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoffeelineAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoffeelineAppApplication.class, args);
	}

}
